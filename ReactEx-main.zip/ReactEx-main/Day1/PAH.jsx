import React from "react";



function Pah() {
    return(
        <>
            <div>
                <h2>
                    Hello!!
                </h2>
            </div>
        
        </>
    )    
}

export default Pah;
