import logo from "/smile_image.jpeg" ;

function Day2CY(){
    return(
        <>
            <h1>Smile Component</h1>
            <h2>Its a functional </h2>
            <img src={logo} alt=''></img>
        </>

    )
}
export default Day2CY;
